<?php

//print_r($_POST); die;
 /*   $res = array(0=>0);
    echo $myJSON = json_encode($res);
    die(); */


include_once("config.php");

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$course = $_POST['course'];
$message = $_POST['message'];
$date = date("Y-m-d");

    $sel_qry = "SELECT * FROM register WHERE email = '$email'";
    $sel_res = mysqli_query($connect, $sel_qry);
    
    if(mysqli_num_rows($sel_res) > 0) {
        
        echo "You have already registered with this email";
        die;
    } else {
    
    $query = "INSERT INTO register(date, fname, lname, email, course, message)  
           VALUES('$date', '$fname', '$lname', '$email', '$course', '$message')";  
           
    $result = mysqli_query($connect, $query);
    
        }
    
    
if($result) {
    
    echo "Thank you for registering. We will get in touch with you shortly";
} else {
    
    echo "There is a problem saving your data. Please try again";
}


?>