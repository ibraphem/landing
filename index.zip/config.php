<?php

$dbhost = 'localhost';
$dbusername = 'root';
$dbpass = "";
$dbname = 'trainingdb';
$connect = mysqli_connect($dbhost, $dbusername, $dbpass, $dbname);


?>